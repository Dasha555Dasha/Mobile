package com.example.myapplication11;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.widget.ImageView;
import android.widget.Button;
import android.view.View;
import android.os.Bundle;


public class MainActivity extends AppCompatActivity {
    AnimationDrawable mAnimation;
    ImageView mImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mImageView = findViewById(R.id.imageView);
        mImageView.setBackgroundResource(R.drawable.emae);
        mAnimation = (AnimationDrawable) mImageView.getBackground();

        Button mStart = findViewById(R.id.button);
        mStart.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                mAnimation.start();
            }
        });
        Button mStop = findViewById(R.id.button2);
        mStop.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                mAnimation.stop();
            }
        });
    }
}
