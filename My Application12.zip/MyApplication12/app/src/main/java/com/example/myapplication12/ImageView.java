package com.example.myapplication12;

import android.view.animation.Animation;

public class ImageView {
    public void startAnimation(Animation animationRotateCenter) {
    }
}
